<script src="<?= (base_url()); ?>vendor/AdminLTE-2.3.11/plugins/iCheck/icheck.min.js"></script>
