										<li class="m-nav__item m-nav__item--home">
										</li>
										<li class="m-nav__separator">
										<a href="<?php echo base_url();?>#" class="m-nav__link m-nav__link--icon">
											<i class="m-nav__link-icon la la-home"></i>
												<span class="m-nav__link-text">
													Home
												</span>
											</a>
										</li>

										<li class="m-nav__separator">
											-
											<a href="#" class="m-nav__link">
												<span class="m-nav__link-text">
													Kuesioner
												</span>
											</a>
										</li>
      