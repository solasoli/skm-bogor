					<!-- BEGIN: Subheader -->
				<div class="m-content">

					<!-- BEGIN: Subheader -->
					<div class="m-portlet">
						<div class="m-portlet__head">
							<div class="m-portlet__head-caption">
								<div class="m-portlet__head-title">
									<ul class="m-subheader__breadcrumbs m-nav m-nav--inline">
      									<?= $contents ?>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<!-- END: Subheader -->
