Skema SKM
      