<style>
.responsive {
    width: 100%;
    height: auto;
}
</style>


                        <div class="m-portlet">
            <!-- /.box-header -->
            <!-- form start -->
                <img src="<?php echo base_url();?>/vendor/images/skemaskm.png" class="responsive">
                </div>
