<?php
		echo "test 123<br>";
		echo "nama : ".$nilai."<br>";
		echo "usia : ".$usia."<br>";
?>