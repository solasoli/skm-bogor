<h1>Belajar</h1>
<p>Index belajar</p>
<a href="<?php echo base_url() ?>belajar/welcome">1. Welcome message</a><br>
<a href="<?php echo base_url() ?>belajar/tes/slamet/36">2. controler</a><br>
<a href="<?php echo base_url() ?>belajar/isi/slamet/36">3. controler dan view</a><br>
<a href="<?php echo base_url() ?>belajar_crud">4. belajar crud</a><br>
<a href="<?php echo base_url() ?>belajar_tmp">5. belajar template</a><br>