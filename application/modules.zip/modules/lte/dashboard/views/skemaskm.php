<style>
.responsive {
    width: 100%;
    height: auto;
}
</style>

<div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Skema SKM</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form">
              <div class="box-body">
                <div class="form-group">
                <img src="<?php echo base_url();?>/vendor/images/skemaskm.png" class="responsive">
                </div>
                </div>
            </form>
          </div>
