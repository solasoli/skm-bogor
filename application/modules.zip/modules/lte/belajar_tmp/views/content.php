    <!-- Main content -->
    <section class="content">
      <?= $contents ?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
