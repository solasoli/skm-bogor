    <section class="content-header">   
      <?= $contents ?>
    </section>

