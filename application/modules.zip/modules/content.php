						<div class="m-portlet__body">
      					<?= $contents ?>
      					</div>
					</div>
				</div>
					<!-- END: Subheader -->
